
#include "sc.h"


using namespace cv;
using namespace std;


// Declared Methods

void makeEnergyMatrix(Mat &in_image, Mat &energyMatrix);
void makeVerticalMatrix(Mat &energyMatrix, vector< vector<double> > &verticalMatrix, int rows, int cols);
void removeVerticalSeam(vector< vector<double> > &horizontalMatrix, Mat &in_image, Mat &out_image);
int minColumnLocation(vector< vector<double> > &matrix, int rows, int cols);
void makeHorizontalMatrixAlt(Mat &energyMatrix, vector< vector<double> > &horizontalMatrix, int rows, int cols);
void removeHorizontalSeamAlt(vector< vector<double> > &horizontalMatrix, Mat &in_image, Mat &out_image);
int minRowLocationAlt(vector< vector<double> > &matrix, int rows, int cols);

/*
* Performs check and make seam carving 
*/

bool seam_carving(Mat& in_image, int new_width, int new_height, Mat& out_image){

    // some sanity checks
    // Check 1 -> new_width <= in_image.cols
    if(new_width>in_image.cols){
        cout<<"Invalid request!!! new_width has to be smaller than the current size!"<<endl;
        return false;
    }
    if(new_height>in_image.rows){
        cout<<"Invalid request!!! ne_height has to be smaller than the current size!"<<endl;
        return false;
    }
    
    if(new_width<=0){
        cout<<"Invalid request!!! new_width has to be positive!"<<endl;
        return false;

    }
    
    if(new_height<=0){
        cout<<"Invalid request!!! new_height has to be positive!"<<endl;
        return false;
        
    }

    
    return seam_carving_trivial(in_image, new_width, new_height, out_image);
}


// seam carves by removing trivial seams
bool seam_carving_trivial(Mat& in_image, int new_width, int new_height, Mat& out_image){

    Mat iimage = in_image.clone();
    Mat oimage = in_image.clone();
    while(iimage.rows!=new_height || iimage.cols!=new_width){
        // horizontal seam if needed
        if(iimage.rows>new_height){
            reduce_horizontal_seam_trivial(iimage, oimage);
            iimage = oimage.clone();
        }
        		
        if(iimage.cols>new_width){
            reduce_vertical_seam_trivial(iimage, oimage);
            iimage = oimage.clone();
        }
    }
    
    out_image = oimage.clone();
    return true;
}


// horizontl trivial seam is a seam through the center of the image
bool reduce_horizontal_seam_trivial(Mat& in_image, Mat& out_image){

    // retrieve the dimensions of the new image
    int rows = in_image.rows;
    int cols = in_image.cols;
    
    // create an image slighly smaller
    out_image = Mat(rows - 1 , cols, CV_8UC3);

	Mat energyMatrix;
	//vector<double> *horizontalMatrix = new vector<double>[rows];
	vector< vector<double> > horizontalMatrix(rows, vector<double>(cols, 0));
	makeEnergyMatrix(in_image, energyMatrix);
	makeHorizontalMatrixAlt(energyMatrix, horizontalMatrix, rows, cols);
	removeHorizontalSeamAlt(horizontalMatrix, in_image, out_image);
    return true;
}

// vertical trivial seam is a seam through the center of the image
bool reduce_vertical_seam_trivial(Mat& in_image, Mat& out_image){
    // retrieve the dimensions of the new image
    int rows = in_image.rows;
    int cols = in_image.cols;
    
    // create an image slighly smaller
    out_image = Mat(rows, cols - 1, CV_8UC3);

	Mat energyMatrix;
	//vector<double> *verticalMatrix = new vector<double>[rows];
	vector< vector<double> > verticalMatrix(rows, vector<double>(cols, 0));
	makeEnergyMatrix(in_image, energyMatrix);
	makeVerticalMatrix(energyMatrix, verticalMatrix, rows, cols);
	removeVerticalSeam(verticalMatrix, in_image, out_image);

	return true;
   
}



/*
* Creates a dynamic horizontal matrix
*/
void makeHorizontalMatrixAlt(Mat &energyMatrix, vector<vector<double>> &horizontalMatrix, int rows, int cols) {

	for (int x = 0; x < rows; x++) {
		horizontalMatrix[x].at(0) = abs((double)energyMatrix.at<char>(x, cols-1));
	}

	for (int y = cols-2; y >=0 ; y--) {
		for (int x = 0; x < rows; x++) {

			//horizontalMatrix[x].push_back(abs((double)energyMatrix.at<char>(x, y)));
			if (x == 0) {
				double minIntensity = min(abs((double)energyMatrix.at<char>(x, y+1) - (double)energyMatrix.at<char>(x, y)) + horizontalMatrix[x].at(y+1), abs((double)energyMatrix.at<char>(x + 1, y+1) - (double)energyMatrix.at<char>(x, y)) + horizontalMatrix[x + 1].at(y+1));
				horizontalMatrix[x].at(y) = minIntensity;
			}
			else if (x == rows - 1) {
				double minIntensity = min(abs((double)energyMatrix.at<char>(x, y+1) - (double)energyMatrix.at<char>(x, y)) + horizontalMatrix[x].at(y+1), abs((double)energyMatrix.at<char>(x - 1, y+1) - (double)energyMatrix.at<char>(x, y)) + horizontalMatrix[x - 1].at(y+1));
				horizontalMatrix[x].at(y) = minIntensity;
			}
			else {
				double minIntensity = min(min(abs((double)energyMatrix.at<char>(x - 1, y+1) - (double)energyMatrix.at<char>(x, y)) + horizontalMatrix[x - 1].at(y + 1), abs((double)energyMatrix.at<char>(x, y + 1) - (double)energyMatrix.at<char>(x, y)) + horizontalMatrix[x].at(y+1)), abs((double)energyMatrix.at<char>(x + 1, y + 1) - (double)energyMatrix.at<char>(x, y)) + horizontalMatrix[x + 1].at(y+1));
				horizontalMatrix[x].at(y) = minIntensity;
			}
		}
	}
}


/*
* remove a horizontal seam
*/
void removeHorizontalSeamAlt(vector<vector<double>> &horizontalMatrix, Mat &in_image, Mat &out_image) {

	int rows = in_image.rows, cols = in_image.cols;
	int minRIndex = minRowLocationAlt(horizontalMatrix, rows, cols);

	for (int c = 0; c < cols; c++) {
		int outRIndex = 0;
		for (int r = 0; r < rows; r++) {
			if (r != minRIndex) {
				out_image.at<Vec3b>(outRIndex++, c) = in_image.at<Vec3b>(r, c);
			}
		}

		if (c == cols-1)
			break;
		if (minRIndex == 0)
			minRIndex = horizontalMatrix[minRIndex].at(c +1) > horizontalMatrix[minRIndex + 1].at(c + 1) ? minRIndex + 1 : minRIndex;
		else if (minRIndex == rows - 1)
			minRIndex = horizontalMatrix[minRIndex].at(c + 1) > horizontalMatrix[minRIndex - 1].at(c + 1) ? minRIndex - 1 : minRIndex;
		else {
			int temp = horizontalMatrix[minRIndex].at(c + 1) > horizontalMatrix[minRIndex + 1].at(c + 1) ? minRIndex + 1 : minRIndex;
			minRIndex = horizontalMatrix[temp].at(c + 1) > horizontalMatrix[minRIndex - 1].at(c + 1) ? minRIndex - 1 : temp;
		}
	}

}


/*
* Creates a dynamic vertical matrix
*/
void makeVerticalMatrix(Mat &energyMatrix, vector<vector<double>> &verticalMatrix, int rows, int cols) {

	for (int y = 0; y < cols; y++) {
		verticalMatrix[0].at(y) = abs((double)energyMatrix.at<char>(0, y));
	}

	for (int x = 1; x < rows; x++) {
		for (int y = 0; y < cols; y++) {
			//verticalMatrix[x].push_back(abs((double)energyMatrix.at<char>(x, y)));

			if (y == 0) {
				double minIntensity = min(abs((double)energyMatrix.at<char>(x-1, y) - (double)energyMatrix.at<char>(x,y))+ verticalMatrix[x - 1].at(y), abs((double)energyMatrix.at<char>(x-1, y+1) - (double)energyMatrix.at<char>(x,y)) + verticalMatrix[x - 1].at(y + 1));
				verticalMatrix[x].at(y) = minIntensity;
			}
			else if (y == cols - 1) {
				double minIntensity = min(abs((double)energyMatrix.at<char>(x-1, y) - (double)energyMatrix.at<char>(x,y)) + verticalMatrix[x - 1].at(y), abs((double)energyMatrix.at<char>(x-1, y-1) - (double)energyMatrix.at<char>(x,y))+ verticalMatrix[x - 1].at(y - 1));
				verticalMatrix[x].at(y) = minIntensity;
			}
			else {
				double minIntensity = min(min(abs((double)energyMatrix.at<char>(x-1, y-1) - (double)energyMatrix.at<char>(x, y)) + verticalMatrix[x - 1].at(y - 1), abs((double)energyMatrix.at<char>(x-1, y) - (double)energyMatrix.at<char>(x, y)) + verticalMatrix[x - 1].at(y)), abs((double)energyMatrix.at<char>(x-1, y+1) - (double)energyMatrix.at<char>(x,y))+ verticalMatrix[x - 1].at(y + 1));
				verticalMatrix[x].at(y) = minIntensity;
			}
		}
	}
}





/*
* removes vertical matrix
*/
void removeVerticalSeam(vector<vector<double>> &verticalMatrix, Mat &in_image, Mat &out_image) {

	int rows = in_image.rows, cols = in_image.cols;
	int minCIndex = minColumnLocation(verticalMatrix, rows, cols);
	for (int r = rows - 1; r >= 0; r--) {
		int outCIndex = 0;
		for (int c = 0; c < cols; c++) {
			if (c != minCIndex) {
				out_image.at<Vec3b>(r, outCIndex++) = in_image.at<Vec3b>(r, c);
			}
		}
		if (r == 0)
			break;
		if (minCIndex == 0) {
			minCIndex = verticalMatrix[r - 1].at(minCIndex) > verticalMatrix[r - 1].at(minCIndex + 1) ? minCIndex + 1 : minCIndex;
		}
		else if (minCIndex == cols - 1) {
			minCIndex = verticalMatrix[r - 1].at(minCIndex) > verticalMatrix[r - 1].at(minCIndex - 1) ? minCIndex - 1 : minCIndex;
		}
		else {
			int temp = verticalMatrix[r - 1].at(minCIndex) > verticalMatrix[r - 1].at(minCIndex - 1) ? minCIndex - 1 : minCIndex;
			minCIndex = verticalMatrix[r - 1].at(minCIndex + 1) > verticalMatrix[r - 1].at(temp) ? temp : minCIndex + 1;
		}
	}
}



/*
* Finds minimum location of the last row
*/
inline int minRowLocationAlt(vector<vector<double>> &matrix, int rows, int cols) {
	// find the minimum element in last row
	double min = matrix[0].at(0);
	int index = 0;
	for (int r = 1; r < rows; r++) {
		if (min > matrix[r].at(0)) {
			min = matrix[r].at(0);
			index = r;
		}
	}

	return index;
}


/*
* Finds minimum location of the last row
*/
inline int minColumnLocation(vector<vector<double>> &matrix, int rows, int cols) {
	/*vector<double>::iterator begin = matrix[rows - 1].begin(),end = matrix[rows - 1].end();
	vector<double>::iterator it = min_element(begin,end);
	return (double)distance(begin, it);*/
	double min = matrix[rows-1].at(0);
	int index = 0;
	for (int c = 1; c < cols; c++) {
		if (min > matrix[rows-1].at(c)) {
			min = matrix[rows-1].at(c);
			index = c;
		}
	}
	return index;
}



/*
* Perform preoperations on matrix and generates an energy matrix
*/
inline void makeEnergyMatrix(Mat &in_image, Mat &energyMatrix){

	Mat greyImage,gaussianImage;
	int scale = 1, delta = 0, ddepth = CV_16S;

	GaussianBlur(in_image, gaussianImage, Size(3, 3), 0, 0, BORDER_DEFAULT);
	cvtColor(gaussianImage, greyImage, COLOR_BGR2GRAY);

	Mat gradientX, gradientY,absoluteX, absoluteY;

	Sobel(greyImage, gradientX, ddepth, 1, 0,3, scale, delta, BORDER_DEFAULT);
	Sobel(greyImage, gradientY, ddepth, 0, 1,3, scale, delta, BORDER_DEFAULT);

	convertScaleAbs(gradientX, absoluteX);
	convertScaleAbs(gradientY, absoluteY);

	addWeighted(absoluteX, 0.5, absoluteY, 0.5, 0, energyMatrix);

}
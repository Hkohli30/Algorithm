// OpenCVSample.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include<opencv2/opencv.hpp>
#include <iostream>
#include<fstream>
//#include<bits/stdc++.h>
#include<cstdio>

using namespace std;
using namespace cv;


// Global variables
const int SOURCE_VAL = -3;
const int SINK_VAL = -7;

// Classes and structures

/*
	Holds the coordinates of the graph
*/
struct Location {
	int xCordinate;
	int yCordinate;
	Location(int xCord = 0, int yCord = 0) :xCordinate{ xCord }, yCordinate{ yCord }{}
};

/*
	Holds the connection between the Vertex
*/
class Edge {
public:
	Location toPixel;
	double weight;
	Edge() : weight{0}{}
	
	Edge(Location location, double weight) : toPixel{ location }, weight{ weight }{}

	bool leadsToSink() {
		if (toPixel.xCordinate == SINK_VAL && toPixel.yCordinate == SINK_VAL)
			return true;
		return false;
	}

	bool isNormalEdge() {
		if (toPixel.xCordinate >= 0 && toPixel.yCordinate >= 0)
			return true;
		return false;
	}

	bool isWeightPositive() {
		if (this->weight > 0.0)
			return true;
		return false;
	}
};

/*
	The Vertex which holds elements for individual pixel
*/
class Vertex {
public:
	Location pixelLocation;
	Location parentLocation;
	bool isVisited;
	vector<Edge> neighbours;

	Vertex() {}
	Vertex(Location pixel, bool isVisited = false) : pixelLocation{ pixel }, isVisited{ isVisited }{}

	void assignParent(Location parentLoc) {
		parentLocation = parentLoc;
	}

	void addEdge(Location location, double weight) {
		neighbours.push_back(Edge(location, weight));
	}

	Edge& getEdge(Location location) {
		for (vector<Edge>::iterator item = neighbours.begin(); item != neighbours.end(); item++) {
			if (location.xCordinate == item->toPixel.xCordinate && location.yCordinate == item->toPixel.yCordinate) {
				return *item;
			}
		}
	}

	bool isSource() {
		if (pixelLocation.xCordinate == SOURCE_VAL && pixelLocation.yCordinate == SOURCE_VAL)
			return true;
		return false;
	}

	bool isParentSource() {
		if (parentLocation.xCordinate == SOURCE_VAL && parentLocation.yCordinate == SOURCE_VAL)
			return true;
		return false;
	}

};



// Local Variables
Vertex apexSource(Location(SOURCE_VAL, SOURCE_VAL));
Vertex apexSink(Location(SINK_VAL, SINK_VAL));


// Function declarations

void performPreProcessing(Mat &in_image, Mat &gaussianBlurredImage);
void parseFiles(const int, char **, Mat &, const char*);
void showImage(string, Mat&);
void assignIndex(vector<Vertex> *graph, const int row, const int col);
void assignSourceSink(vector<Vertex> *graph, char *fileName, const int width, const int height);
void assignNeighbourWeight(vector<Vertex> *graph, Mat& image, const int imageRows, const int imageCols);
inline bool bfsTraverse(vector<Vertex> *graph, Vertex, Vertex&);
void performCut(vector<Vertex> *graph, Mat&, const int imageRows, const int imageCols);
inline void minMaxFord(vector<Vertex> * graph, const int imageRows, const  int imageCols);
inline Vertex& getVertex(vector<Vertex> *graph, const Location &location);


/*
* @arg: argc : size of the arguments in the command line
* @arg:  argv : array which holds the value of command line strings
*
*/
int main(int argc, char** argv)
{


	// input and output image and gaussian blurred image
	Mat in_image, out_image;
	Mat gaussianBlurredImage;

	// parse files
	parseFiles(argc, argv, in_image, argv[1]);
	out_image = in_image.clone();

	//Perform gaussian preprocessing
	performPreProcessing(in_image, gaussianBlurredImage);

	// Initialize graph, initialize weights and neighbours
	int imageRows = in_image.rows, imageCols = in_image.cols;
	vector<Vertex> *graph = new vector<Vertex>[imageRows];
	assignIndex(graph, imageRows, imageCols);
	assignSourceSink(graph, argv[2], imageCols, imageRows);
	assignNeighbourWeight(graph, gaussianBlurredImage, imageRows, imageCols);

	// Ford fulkerson and perform cut
	minMaxFord(graph, imageRows, imageCols);
	performCut(graph, out_image, imageRows, imageCols);

	// write Image
	imwrite(argv[3], out_image);
	namedWindow("Final Output", WINDOW_AUTOSIZE);
	imshow("Final Output", out_image);
	waitKey(0);

	// Free Up memory
	delete graph;
	return 0;
}

/*
* @arg: graph : graph of the image
* @arg: rows : number of rows of image
* @arg: col : number of columns of image
*
*/
void assignIndex(vector<Vertex> *graph, int row, int col) {

	for (int i = 0; i < row; i++) {
		for (int j = 0; j < col; j++) {
			graph[i].push_back(Vertex(Location(i, j)));
		}
	}
}


/*
* @arg: graph : graph of the image
* @arg: fileName : Name of the file for input
* @arg: width : width of image
* @arg: height : height of image
*/
void assignSourceSink(vector<Vertex> *graph, char *fileName, int width, int height) {
	// the output image

	ifstream f(fileName);
	if (!f) {
		cout << "Could not load initial mask file!!!" << endl;
		exit(-1);
	}
	int n;
	f >> n;
	// get the initil pixels
	for (int i = 0; i < n; ++i) {
		int x, y, t;
		f >> x >> y >> t;

		if (x < 0 || x >= width || y < 0 || y >= height) {
			cout << "Invalid pixel mask!" << endl;
			exit(-1);
		}
		if (t == 1) {
			// Source Then add edge from apex source
			apexSource.addEdge(Location(y, x), LONG_MAX);
		}
		else {
			// Add edge to Sink
			graph[y].at(x).addEdge(Location(SINK_VAL, SINK_VAL), LONG_MAX);
		}

	}
}

/*
* @arg: graph : graph of the image
* @arg: imageRows : number of rows of image
* @arg: imageCols : number of columns of image
*
*/
void assignNeighbourWeight(vector<Vertex>* graph, Mat& image, int imageRows, int imageCols)
{
	for (int i = 0; i < imageRows; i++) {
		for (int j = 0; j < imageCols; j++) {
			double weight;
			// holds all the neighbours
			vector<Location> neighboursHolder;

			// Checking the borders and assigning the neighbours
			//not the first row index
			if (i > 0)
				neighboursHolder.push_back(Location(i - 1, j));
			// not the last row index
			if (i < imageRows - 1)
				neighboursHolder.push_back(Location(i + 1, j));
			// not the first column index
			if (j > 0)
				neighboursHolder.push_back(Location(i, j - 1));
			// not the last column index
			if (j < imageCols - 1)
				neighboursHolder.push_back(Location(i, j + 1));

			// Assigning weight
			for (vector<Location>::iterator location = neighboursHolder.begin(); location != neighboursHolder.end(); location++) {
				double difference = (image.at<uchar>(i, j) - image.at<uchar>(location->xCordinate, location->yCordinate));
				if (difference > 0.5)
					weight = 1;
				else
					weight = LONG_MAX;
				graph[i].at(j).addEdge(*location, weight);
			}
		}
	}
}

/*
* @arg: graph : graph of the image
* @arg: source : source Vertex
* @arg: destination : destination of the source
* @return : if destination is traversed or not
*/
inline bool bfsTraverse(vector<Vertex>* graph, const Vertex source, Vertex &destination)
{
	queue<Vertex> traversalQueue;
	traversalQueue.push(source);
	while (!traversalQueue.empty()) {
		// get the first element
		Vertex vertex = traversalQueue.front();
		traversalQueue.pop();

		for (vector<Edge>::iterator edge = vertex.neighbours.begin(); edge != vertex.neighbours.end(); edge++) {
			if (edge->isNormalEdge()) {
				Vertex *element = &(getVertex(graph, edge->toPixel));
				if (!element->isVisited && edge->isWeightPositive()) {
					// Assign parent and set visited true
					element->isVisited = true;
					element->assignParent(vertex.pixelLocation);
					traversalQueue.push(*element);
				}
			}
			else if (edge->leadsToSink() && edge->isWeightPositive()) {
				// Assign parent and set visted true
				destination.isVisited = true;
				destination.assignParent(vertex.pixelLocation);
				return true;
			}
		}
	}

	return destination.isVisited;
}

/*
* @arg: graph : graph of the image
* @arg: out_image : output image
* @arg: imageRows : Rows of the image
* @arg: imageCols : if destination is traversed or not
*/
void performCut(vector<Vertex>* graph, Mat& out_image, int imageRows, int imageCols)
{
	for (int i = 0; i < imageRows; i++) {
		for (int j = 0; j < imageCols; j++) {
			Vec3b pixel = out_image.at<Vec3b>(i, j);
			if (graph[i].at(j).isVisited) {
				pixel[0] = 255;
				pixel[1] = 255;
				pixel[2] = 255;
			}
			else {
				pixel[0] = 0;
				pixel[1] = 0;
				pixel[2] = 0;
			}
			out_image.at<Vec3b>(i, j) = pixel;
		}
	}
}

/*
* @arg: argc : the length of the arguments
* @arg: argv : 2-d array containing all the strings from command line
* @arg: in_image : Input image
* @arg: imageName : name of the image
*/
void parseFiles(const int argc, char **argv, Mat &in_image, const char* imageName) {

	in_image = imread(imageName);
	if (argc != 4) {
		cout << "Usage: ../seg input_image initialization_file output_mask" << endl;
		exit(-1);
	}

	// Load the input image
	// the image should be a 3 channel image by default but we will double check that in teh seam_carving

	if (!in_image.data)
	{
		cout << "Could not load input image!!!" << endl;
		exit(-1);
	}

	if (in_image.channels() != 3) {
		cout << "Image does not have 3 channels!!! " << in_image.depth() << endl;
		exit(-1);
	}
}

/*
* @arg: in_image : input image
* @arg: gaussianBlurredImage : The blurred image
*/
void performPreProcessing(Mat &in_image, Mat &gaussianBlurredImage) {

	// Blurring the image
	GaussianBlur(in_image, gaussianBlurredImage, Size(3, 3), 0, 0, BORDER_DEFAULT);
	// Converting it into greyScale
	cvtColor(gaussianBlurredImage, gaussianBlurredImage, CV_BGR2GRAY);
	// Sharepning the image with max and min value
	normalize(gaussianBlurredImage, gaussianBlurredImage, 0, 255, NORM_MINMAX, CV_8UC3);
}


/*
* @arg: graph : graph of the image
* @arg: imageRows : number of rows of image
*/
void resetVertices(vector<Vertex> * graph, int imageRows) {
	for (int i = 0; i < imageRows; i++) {
		for (vector<Vertex>::iterator v = graph[i].begin(); v != graph[i].end(); v++) {
			v->isVisited = false;
		}
	}
}

/*
* @arg: graph : graph of the image
* @arg: location : x and y coordinates of vertex
* @return : Vertex address from graph
*/
inline Vertex& getVertex(vector<Vertex> *graph, const Location &location) {
	return graph[location.xCordinate].at(location.yCordinate);
}

/*
* @arg: graph : graph of the image
* @arg: imageRows : number of rows of image
* @arg: imageCols : number of columns of image
*/

inline void minMaxFord(vector<Vertex> *graph, const int imageRows, const int imageCols) {
	double flowSummation = 0;
	while (bfsTraverse(graph, apexSource, apexSink)) {
		// Reset the visited paths
		resetVertices(graph, imageRows);
		// Set sink to false
		apexSink.isVisited = false;

		Vertex traverseVertex = getVertex(graph, apexSink.parentLocation);
		double minimumFlow = LONG_MAX;
		while (!traverseVertex.isSource()) {
			Vertex parentVertex;
			if (traverseVertex.isParentSource())
				parentVertex = apexSource;
			else
				parentVertex = getVertex(graph, traverseVertex.parentLocation);
			minimumFlow = min(minimumFlow, parentVertex.getEdge(traverseVertex.pixelLocation).weight);
			traverseVertex = parentVertex;
		}

		traverseVertex = getVertex(graph, apexSink.parentLocation);
		while (true) {
			if (traverseVertex.isParentSource())
				break;
			Vertex &parentVertex = getVertex(graph, traverseVertex.parentLocation);
			// Get both the vertices
			Edge *recevingFlow = &parentVertex.getEdge(traverseVertex.pixelLocation);
			Edge *sendingFlow = &traverseVertex.getEdge(parentVertex.pixelLocation);
			// Updating Flows
			recevingFlow->weight = recevingFlow->weight - minimumFlow;
			sendingFlow->weight = sendingFlow->weight + minimumFlow;
			traverseVertex = parentVertex;
		}
		flowSummation += minimumFlow;
	}
}
